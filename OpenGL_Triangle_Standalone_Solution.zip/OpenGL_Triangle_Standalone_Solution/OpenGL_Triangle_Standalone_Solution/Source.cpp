#include "glad/glad.h"
#include "GLFW/glfw3.h"

#include <iostream>

#include "hidden_stuff.h" //Carlos


int main()
{
    unsigned int shaderProgram;
    unsigned int vertex_buffer_object, vertex_array_object;

    float vertices[] = {
        // x,y,z
        -0.5f, -0.5, 0.0f, // left  
         0.5f, -0.5f, 0.0f, // right 
         0.0f,  0.5f, 0.0f  // top   
    };
    int vertices_array_length = 9;// = sizeof(vertices) / sizeof(vertices[0]); //for a triangle, this value will be 9.

    build_OpenGL_Stuff(vertices, vertices_array_length, shaderProgram, vertex_array_object, vertex_buffer_object);


    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        // draw our first triangle
        glUseProgram(shaderProgram);
        glBindVertexArray(vertex_array_object); // seeing as we only have a single VAO there's no need to bind it every time, but we'll do so to keep things a bit more organized
        int numberOfVertices = 3; // For a triangle, the number of vertices is 3.
        glDrawArrays(GL_TRIANGLES, 0, numberOfVertices);
        // glBindVertexArray(0); // no need to unbind it every time 

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &vertex_array_object);
    glDeleteBuffers(1, &vertex_buffer_object);
    glDeleteProgram(shaderProgram);

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}